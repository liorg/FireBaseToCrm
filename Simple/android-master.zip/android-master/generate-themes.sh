#!/bin/sh
python generate-theme.py ash 210 0
python generate-theme.py dusk 210 0.55
python generate-theme.py emerald 110 0.55
python generate-theme.py orchid 314 0.55
python generate-theme.py rust 0 0.55
python generate-theme.py sand 45 0.55
python generate-theme.py tropic 180 0.55

